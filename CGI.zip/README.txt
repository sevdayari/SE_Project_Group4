Copy and replace the folder in the following directories:

C:\wamp64\cgi-bin
C:\wamp64\bin\apache\apache2.4.54.2\cgi-bin